<template>
  <div>
    <nav>
      <router-link to="/">홈</router-link> |
      <router-link to="/about">소개</router-link> |
      <router-link to="/reser">예약하기</router-link>
    </nav>
  </div>
</template>
<script setup></script>

<style scoped></style>
